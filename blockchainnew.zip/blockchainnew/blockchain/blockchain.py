from flask import Flask, request, jsonify, render_template
from time import time
from flask_cors import CORS
from collections import OrderedDict
from Crypto.Signature import PKCS1_v1_5
from Crypto.PublicKey import RSA
import binascii
from Crypto.Hash import SHA
from uuid import uuid4
import json
import requests
import hashlib
import ast
import os

from urllib.parse import urlparse
MINING_DIFFICULTY = 3
global node

# hashofusertx=[]
class MerkleNode:
    """
    Stores the hash and the parent.
    """

    def __init__(self, hash):
        self.hash = hash
        self.parent = None
        self.left_child = None
        self.right_child = None
        self.prev=None


# if leave yes then transaction node not null

class MerkleTree:
    """
    Stores the leaves and the root hash of the tree.
    """
    level = 0
    def __init__(self,data_chunks):
        leaves = []
        self.leaves = leaves
        for chunk in data_chunks:
            node = MerkleNode(self.compute_hash(chunk))
            self.node=node
            node.prev=chunk
            leaves.append(node)

        self.root = self.build_merkle_tree(leaves)

    def build_merkle_tree(self, leaves):
        """
        Builds the Merkle tree from a list of leaves. In case of an odd number of leaves, the last leaf is duplicated.
        """
        num_leaves = len(leaves)
        # print(num_leaves)
        if num_leaves == 1:
            return leaves[0]

        parents = []

        i = 0
        while i < num_leaves:

            left_child = leaves[i]
            right_child = leaves[i + 1] if i + 1 < num_leaves else left_child

            parents.append(self.create_parent(left_child, right_child))

            i += 2
        self.level = self.level+1
        return self.build_merkle_tree(parents)

    def create_parent(self, left_child, right_child):
        """
        Creates the parent node from the children, and updates
        their parent field.
        """
        parent = MerkleNode(self.compute_hash(left_child.hash + right_child.hash))
        # print("hello parent merkel tree")
        left_child.parent, right_child.parent = parent, parent

        # print("Left child: {}, Right child: {}, Parent: {}, Level: {}".format(
        #     left_child.hash, right_child.hash, parent.hash, self.level))
        # hashofusertx.append(left_child.hash)
        # hashofusertx.append(right_child.hash)
        # print("Hash values of user trasnvtions")
        # print(hashofusertx)
        parent.left_child, parent.right_child = left_child, right_child
        left_child.parent, right_child.parent = parent, parent

        return parent

    def get_txpath(self, chunk_hash):
        """
        Checks if the leaf exists, and returns the audit trail
        in case it does.
        """
        for leaf in self.leaves:
            if leaf.hash == chunk_hash:
                # print("Leaf exists")
                return self.generate_txpath(leaf)
        return False

    def generate_txpath(self, merkle_node, trail=[]):
        """
        Generates the audit trail in a bottom-up fashion
        """
        if merkle_node == self.root:
            trail.append(merkle_node.hash)
            return trail

        # check if the merkle_node is the left child or the right child
        is_left = merkle_node.parent.left_child == merkle_node
        if is_left:
            # since the current node is left child, right child is
            # needed for the audit trail. We'll need this info later
            # for audit proof.
            trail.append((merkle_node.parent.right_child.hash, not is_left))
            return self.generate_txpath(merkle_node.parent, trail)
        else:
            trail.append((merkle_node.parent.left_child.hash,is_left))
            return self.generate_txpath(merkle_node.parent, trail)

    @staticmethod
    def compute_hash(data):
        # data = data.encode('utf-8')
        # return sha256(data).hexdigest()
        return hashlib.sha256(data.encode('utf-8')).hexdigest()

    @staticmethod
    def amtintransaction(self,checkpath):
        if checkpath:
            print(node.prev)
        else:
            print("sorry dude wrong info")

def verify_txpath(chunk_hash, audit_trail):
    # Performs the audit-proof from the audit_trail received
    # from the trusted server.
    proof_till_now = chunk_hash
    for node in audit_trail[:-1]:
        hash = node[0]
        is_left = node[1]
        if is_left:
            # the order of hash concatenation depends on whether the
            # the node is a left child or right child of its parent
            proof_till_now = MerkleTree.compute_hash(hash + proof_till_now)
        else:
            proof_till_now = MerkleTree.compute_hash(proof_till_now + hash)
        print(proof_till_now)

    # verifying the computed root hash against the actual root hash
    return proof_till_now == audit_trail[-1]





class Blockchain:
    def __init__(self):
        self.transactions = []  # all the transactions
        self.chain = []  # contains all the block of the blockchain
        print("call bby")
        self.create_block('','','','',None)  # to create block this is genesis block
        self.node_id = str(uuid4()).replace('-','')   # Every node will have a unique id
        self.nodes = set()
        # self.merkelroot()
    def create_block(self, virtualname,nonce, prev_hash,hashgenerated,usertx):
        """Create block and then add it in the existing blockchain"""
        """using dictionary (key:value) to store the parameters"""
        # if len(self.chain)==1:
        #     block = {
        #         'block_number': len(self.chain),  # each block will have unique identity
        #         'timestamp': time(),  # getting the time of the creation of block
        #         'nonce': nonce,  # getting nonce
        #         'transactions': self.transactions,  # for now getting all the transactions from the list of transactions
        #         'prev_hash': prev_hash,  # hash of the previous block
        #         'merkle_root': hashgenerated,
        #         'usertx':usertx
        #     }



        if virtualname=="VE#FE":
            block = {
                'block_number': len(self.chain),  # each block will have unique identity
                'timestamp': time(),  # getting the time of the creation of block
                'nonce': nonce,  # getting nonce
                'transactions': self.transactions,  # for now getting all the transactions from the list of transactions
                'prev_hash': prev_hash,  # hash of the previous block
                'merkle_root': hashgenerated
            }
            virtualname=usertx[0]
        else:
            block = {
                'block_number': len(self.chain)+1,  # each block will have unique identity
                'timestamp': time(),  # getting the time of the creation of block
                'nonce': nonce,  # getting nonce
                'transactions': self.transactions,  # for now getting all the transactions from the list of transactions
                'prev_hash': prev_hash,  # hash of the previous block
                'merkle_root': hashgenerated,
                'usertx':usertx
            }
        # preventing transaction doing two times for same
        # print("block")
        # print(block)
        # for i in range(len(filedict)):
        #     print(filedict[i])
        #     if block==filedict[i]:
        #         s={
        #             'message':"same transaction copied"
        #         }
        #         print(s)
        #         return s

        self.block = block
        #adding block  locally into the file name , how to access the virtualid name is erorr

        # all_files = os.listdir("blockchain_client/")  # imagine you're one directory above test dir
        # print(all_files)
        # text_files = [f for f in os.listdir("blockchain_client/") if f.endswith('.txt')]
        # print(text_files[0])
        file_object= "blockchain_client/{virtualid}.txt".format(virtualid=virtualname)

        f = open(file_object, "a")
        f.write(json.dumps(block,sort_keys=True) + "\n")
        f.close()


        f = open("publicledger.txt", "a")
        f.write(json.dumps(block, sort_keys=True) +";")
        f.close()
        #checking for source id to be non repeative
        # file_object1="blockchain_client/sourceids.txt"

        # virtualid=None
        # reset current list of transaction
        self.transactions = []
        # append the block to the list of blocks
        # if len(self.transactions)%5==0:
        #     self.chain.append(block)
        self.chain.append(block)


        return block

    def transaction_signatureverification(self, senderpublickey, signature, transaction):
        public_key = RSA.importKey(binascii.unhexlify(senderpublickey))
        verifier = PKCS1_v1_5.new(public_key)
        h = SHA.new(str(transaction).encode('utf8'))
        try:
            verifier.verify(h, binascii.unhexlify(signature))
            return True
        except ValueError:
            return False

    def submit_transaction(self,virtualname,senderid, senderpublickey, signature,finaldestinationsid,finalamount,finalpath,finalrecipientpublickeys,finalblocks,finalhashtrans,finalrecipientvirtualname):
        # In this we will first verify signature of the transaction and then added it in the transaction list
        # get the values and form transaction using OrderedDict
        print(finalpath)
        transaction = OrderedDict({
            'virtualname':virtualname,
            'senderid':senderid,
            'senderpublickey': senderpublickey,
            'recipientpublickey': finalrecipientpublickeys,
            'destinationid':finaldestinationsid,
            'amount':finalamount,
            'pathtransactions':finalpath,
            'blocks':finalblocks,
            'prevhashtrans':finalhashtrans,
            'recipientvirtualname':finalrecipientvirtualname
        })
        # print(transaction)
        #flag=1
        signature_verification = self.transaction_signatureverification(senderpublickey, signature, transaction)
        if signature_verification:
            self.transactions.append(transaction)  # transaction added to the block

            return len(self.chain)+1

        else:
            return False

    def valid_proof(self, hashgenerated, last_hash, nonce, difficulty=MINING_DIFFICULTY):
        guess = (str(hashgenerated) + str(last_hash) + str(nonce))
        guess_hash = hashlib.sha256(guess.encode()).hexdigest()
        return guess_hash[:difficulty] == '0' * difficulty

    @staticmethod
    def hash(block):
        block_string = json.dumps(block,sort_keys=True)  # convert object to json string and use sort keys to make them in ordered form
        hashof_block = hashlib.sha256(block_string.encode()).hexdigest()
        return hashof_block

    def proofofwork(self,hashgenerated):
        # for transactions we will pass the merkle root of all the transactions
        # print("merkel root")
        #
        # hashgenerated = self.merkelroot()
        # self.block['merkelroot']=hashgenerated
        # merkle_tree = MerkleTree(listoftrans)
        # for i in range(len(listoftrans)):
        #     # error causing saying getpath need one more arguement
        #     details_usertx.append({"tx hash": MerkleTree.compute_hash(listoftrans[i]),"path": [int(self.chain[-1]["block_number"]) + 1,merkle_tree.get_txpath(MerkleTree.compute_hash(listoftrans[i]))]})
        # print(details_usertx)

        lastblocks = self.chain[-1]
        last_hash = self.hash(lastblocks)
        nonce = 0
        while self.valid_proof(hashgenerated, last_hash, nonce) is False:
            nonce = nonce+1

        return nonce

    def valid_chain(self, chain):
        last_block = chain[0]
        index = 1

        while index < len(chain):
            current_block = chain[index]
            if current_block['prev_hash'] != self.hash(last_block):
                return False
            transactions = current_block['transactions']
            transaction_elements = ['sender_publickey', 'recipient_publickey', 'amount']
            transactions = [OrderedDict((k, transaction[k]) for k in transaction_elements) for transaction in
                            transactions]

            if not self.valid_proof(transactions,current_block['prev_hash'], current_block['nonce'], MINING_DIFFICULTY):
                return False

            last_block = current_block
            index = index+1

        return True

    def resolve_conflicts(self):
        neighbours=self.nodes
        new_chain=None

        max_length_chain=len(self.chain)
        for node in neighbours:
           response = requests.get('http://'+node+'/chain-of-blocks')
           if response.status_code==200:
            length = response.json()['length_of_blockchain']
            chainofblocks = response.json()['chain_of_blocks']

            if length > max_length_chain and self.valid_chain(chainofblocks):
                max_length_chain=length
                new_chain=chain
        if new_chain:
            self.chain=new_chain
            return True

        return False

    def register_node(self, node_url):  # adding the new URL node into the list of nodes
        parsed_url = urlparse(node_url)
        if parsed_url.netloc:
            self.nodes.add(parsed_url.netloc)
        elif parsed_url.path:
            self.nodes.add(parsed_url.path)
        else:
            raise ValueError('Invalid URL')

    def merkelroot(self):
        listoftrans = []
        details_usertx = []
        usertx=[]
        # print("blockchain transaction.0")
        # print(self.transactions[-1])
        # print("lengthof transactions")
        # print(len(self.transactions))
        for i in range(len(self.transactions[-1]["amount"])):
            transaction_str ={"virtualname":self.transactions[-1]['virtualname'],"sourceid": self.transactions[-1]['senderid'],"senderpublickey": self.transactions[-1]['senderpublickey'], "recipientpublickey": self.transactions[-1]['recipientpublickey'][i], "destinationid": self.transactions[-1]['destinationid'][i],
                               "amount": self.transactions[-1]['amount'][i],
                               "pathtransactions": self.transactions[-1]['pathtransactions'][i],
                            "previous_block":self.transactions[-1]["blocks"][i],
                            "prev_hash":self.transactions[-1]["prevhashtrans"][i],
                            "recipient_virtual_name":self.transactions[-1]["recipientvirtualname"][i]}
            #"blockno": self.block["block_number"]+1
            # print(transaction_str)
            details_usertx.append(transaction_str) #json format
            listoftrans.append(json.dumps(transaction_str, sort_keys=True))

        # print("List of transactions")
        # print(details_usertx)
        # print(hashofusertx)
        # print(listoftrans)
        merkle_tree = MerkleTree(listoftrans)
        # print(merkle_tree.get_txpath(MerkleTree.compute_hash(listoftrans[1])))
        #commenting below loop on 5/7/2022
        # for i in range(len(listoftrans)):
        #     # error causing saying getpath need one more arguement
        #     hash=MerkleTree.compute_hash(listoftrans[i])
        #     # print(hash)
        #     details_usertx.append({"tx hash": MerkleTree.compute_hash(listoftrans[i]),
        #                            "path": [self.block["block_number"]+1,merkle_tree.get_txpath(hash)]})
        # print(details_usertx)
        # hashoftx=input('enter the hash of tx to verify')
        # txpath = merkle_tree.get_txpath(hashoftx)
        # print(txpath)
        # verify_txpath(hashoftx, txpath)

        i=0
        newtxpath = []
        while(i<len(listoftrans)):
            # print("hash")
            hashoftx=MerkleTree.compute_hash(listoftrans[i])
            txpath=merkle_tree.get_txpath(hashoftx)
            # print("txpath")
            # print(txpath)
            # print("before slicing")
            # print(txpath)
            # # checking condition for the correct path
            # for j in range(len(txpath)):
            #     if len(txpath)==1:
            #         break;
            #     if (txpath[j][1]==False) and type(txpath[j+1])==str:
            #         txpath=txpath[:j+1]
            usertx.append({"tx_hash": hashoftx, "path":txpath})
            i=i+1

        j = 0
        start = 0
        while (len(txpath) > j):
            if len(txpath) == 1:
                newtxpath.append(txpath[0])
                print(newtxpath)
                break;
            if len(txpath[j]) == 64:
                newtxpath.append(txpath[start:start + len(listoftrans)])
                start = start + len(listoftrans)
            j = j + 1
            print(newtxpath)
        for i in range(len(listoftrans)):
            usertx[i]["path"]=newtxpath[i]
        print(usertx)
        response={
            "listoftrans":details_usertx,
            'virtualname':transaction_str['virtualname'],
            'hashgenerated':merkle_tree.root.hash,
            "usertx":usertx
            # 'blockno': transaction_str['blockno'],
            # 'pathtransactions': transaction_str['pathtransactions']
        }
        return response


































# create object of the class Blockchain
blockchain = Blockchain()

"""  use flask framework for the interface and to run the node """
app = Flask(__name__)
CORS(app)


@app.route("/")  # if request contains / then this function will run (Default)
def index():
    return render_template("./index.html")  # this function will redirect to index.html file in templates folder

@app.route("/configure")  # if request contains / then this function will run (Default)
def configure():
    return render_template("./configure.html")



@app.route("/transactions/get", methods=['GET'])
def gettransaction():
    transactions = blockchain.transactions
    response = {'transactions': transactions}
    return jsonify(response), 200


@app.route("/mine-transactions", methods=['GET'])
def minetransaction():
    response=blockchain.merkelroot()
    usertx=response["usertx"] #path and hash of transaction
    hashgenerated=response['hashgenerated'] #current merkle root of input transactions
    virtualname=response['virtualname']
    listoftrans=response["listoftrans"]
    print("listoftrans in minetransaction")
    print(listoftrans)
    nonce = blockchain.proofofwork(hashgenerated)
    last_block = blockchain.chain[-1]
    prev_hash = blockchain.hash(last_block) # compute the hash of the previous block
    # if len(blockchain.transactions) % 5 ==0:

    f = open('publicledger.txt', 'r')
    var1=f.read()

    # print(var1)
    newcheck=var1.strip('][').split(';')
    # print(type(newcheck))
    # # print("printing list of dict in str")
    # # print(newcheck)
    # # listnew=newcheck[:-1]
    # #filedict is list of existing blocks from public ledge
    filedict=[]
    # # print("listnew printing machine")
    # # print(listnew)
    for i in range(len(newcheck)-1):
        filedict.append(json.loads(newcheck[i]))
    print("filedict")
    print(filedict)
    # admin block number 1 check

    # print(listoftrans)
    virtual_name_verification_c = 0
    # Blockno_verification_c = 0
    pathverification_c = 0
    sourceidverification_c = 0
    amountverification_c = 0
    rec_virtual_name_auth_c = 0

    virtual_name_verification = False
    Blockno_verification = False
    pathverification = False
    sourceidverification=False
    amountverification=False
    rec_virtual_name_auth= False #to check whether given virtual name exits  or not

    dir_path = r'blockchain_client/'
    # list to store files
    res = []
    for path in os.listdir(dir_path):
        # check if current path is a file
        if os.path.isfile(os.path.join(dir_path, path)):
            res.append(path)
    print("Res")
    print(res)
    print(listoftrans)
    for i in range(len(listoftrans)):
        for s in res:
            # checking virtual name exists or not in the ledger through files name
            # print("s")
            # print(s)
            # print("textfile")
            # print("{username}.txt".format(username=listoftrans[i]["recipient_virtual_name"]))
            # print(type("{username}.txt".format(username=listoftrans[i]["recipient_virtual_name"])))
            # print(type(s))
            if "{username}.txt".format(username=listoftrans[i]["recipient_virtual_name"]) == s:
                print("match")
                rec_virtual_name_auth = True
                rec_virtual_name_auth_c = rec_virtual_name_auth_c + 1
            else:
                virtual_name_auth = False

    filename1 = "sourceids.txt"
    random_sourceid=str(listoftrans[0]["sourceid"])
    file_exists = os.path.exists(filename1)
    if file_exists:
        sd = open(filename1)
        sd = open(filename1, "r")
        data = sd.read()
        data = (data.split(" "))[:-1]
        for s in data:
            if random_sourceid == s:
                s = {
                    "message": "Username Already taken!"
                }
                print("already used source id")
                # jsonify(s)
                # return s
            else:
                sd = open(filename1, "a")
                sd.write(str(random_sourceid) + " ")
    else:
        sd = open(filename1, "x")
        sd = open(filename1, "a")
        sd.write(str(random_sourceid) + " ")
    sd.close()
    #here the end of source id checker

    # file_object1 = "blockchain_client/sourceids.txt"
    # sd = open(file_object1)
    # readfile = sd.read()
    # for i in range(len(listoftrans)):
    #     data=listoftrans[i]["sourceid"]
    #     if data in readfile:
    #         readvid='blockchain_client/{virtualid}.txt'.format(virtualid=listoftrans[i]['virtualname'])
    #         sd1=open(readvid,'r')
    #         print("sd1")
    #         print(sd1.read())
    #         try:
    #             readvid1=json.loads(sd1.read())
    #         except:
    #             print("source id used already")
    #             response = {
    #                 "message2": "hello wrong"
    #             }
    #             sd.close()
    #             return response
    #
    #         if readvid1["Admin"]=="Ve#@1" and len(readvid1)==3:
    #             pass
    #         else:
    #             print("source id used already")
    #             response = {
    #                 "message2": "hello wrong"
    #             }
    #             sd.close()
    #             return response
    # sd.close()


    for i in range(len(filedict)):
        checkpath = []
        finalpath=[]
        for j in range(len(listoftrans)):
            if int(filedict[i]["block_number"])==int(listoftrans[j]["previous_block"]):
                print("blcok no verified")
                Blockno_verification=True
                # Blockno_verification_c=Blockno_verification_c+1
                print(filedict[i]["transactions"])
                if len(filedict[i]['transactions'])==0:
                    continue
                else:
                    for k in range(len(filedict[i]["transactions"])):
                        print("hey")
                        print(filedict[i]["transactions"])
                        print(filedict[i]["transactions"][k]['recipientvirtualname'])
                        for p in range(len(filedict[i]["transactions"][k]['recipientvirtualname'])):
                            if virtualname==filedict[i]["transactions"][k]['recipientvirtualname'][p]:
                                virtual_name_verification=True
                                virtual_name_verification_c=virtual_name_verification_c+1
                                print("virtualname verified")
                                str_filedict = [str(x) for x in (filedict[i]["transactions"])]
                                transtree = MerkleTree(str_filedict)
                                checkpath.append(listoftrans[j]["pathtransactions"])
                                print(checkpath)
                                print(len(checkpath[0]))
                                # print(type(checkpath[p]))
                                if len(checkpath[0])==64:
                                    finalpath=[]
                                    finalpath.append(listoftrans[j]["pathtransactions"])
                                    print("true")
                                else:
                                    print("false")
                                    print(listoftrans[j]["pathtransactions"])
                                    replacedpath=listoftrans[j]["pathtransactions"].replace("false", '"false"')
                                    replacedpath=replacedpath.replace("true", '"True"')
                                    mylist = ast.literal_eval(replacedpath)
                                    print(mylist)
                                    for i in range(len(mylist) - 1):
                                        if mylist[i][1] == 'false':
                                            print(mylist[i][1])
                                            mylist[i][1] = False
                                        else:
                                            print(mylist[i][1])
                                            mylist[i][1] = True
                                    finalpath = list(mylist)
                                    # finalpath.append(checkpath[p])
                                #checking the data for the hash of transaction to access different fields
                                #checking for admin transaction
                                if verify_txpath(listoftrans[j]["prev_hash"],finalpath):
                                        print("path verified")
                                        pathverification_c=pathverification_c+1
                                        pathverification=True
                                        var=transtree.node.prev
                                        print(var)
                                        transnode = json.loads(var.replace("'", '"'))
                                        print(transnode['destinationid'])
                                        print(listoftrans[j]["sourceid"])
                                        # nodetx=MerkleNode(filedict[i]["transactions"][0]["adminhash"])
                                        if transnode['destinationid'][p]==listoftrans[j]["sourceid"]:
                                            print("sourceid veriified")
                                            sourceidverification=True
                                            sourceidverification_c=sourceidverification_c+1
                                            print("requested amount checking")
                                            if transnode['virtualname']=='VE#FE':
                                                if int(listoftrans[j]["amount"])>int(transnode['initialamt']):
                                                    amountverification=False
                                                    # print("not sufficient amount ")
                                                    # response = {
                                                    #     "message2": "hello wrong"
                                                    # }
                                                    # return response
                                                else:
                                                    amountverification=True
                                                    amountverification_c = amountverification_c + 1
                                                    # if listoftrans[-1]["amount"][j]<=(MerkleNode("hashoftransaction").prev):
                                                    #     print("amount should be less than path provided")
                                                    #     break;
                                                    # else:
                                                    # block=blockchain.create_block(virtualname, nonce, prev_hash, hashgenerated,usertx)
                                                    # response = {
                                                    #     'message': 'new block created',
                                                    #     'block_number': block['block_number'],
                                                    #     'block_transactions': block['transactions'],
                                                    #     'block_nonce': block['nonce'],
                                                    #     'block_prev_hash': block['prev_hash'],
                                                    #     'block_merkle_root': block['merkle_root']
                                                    # }
                                                    # return jsonify(response), 200
                                            elif int(listoftrans[j]["amount"])<int(transnode['amount'][p]):
                                                amountverification=True
                                                amountverification_c = amountverification_c + 1
                                                # block = blockchain.create_block(virtualname, nonce, prev_hash,
                                                #                                 hashgenerated, usertx)
                                                # response = {
                                                #     'message': 'new block created',
                                                #     'block_number': block['block_number'],
                                                #     'block_transactions': block['transactions'],
                                                #     'block_nonce': block['nonce'],
                                                #     'block_prev_hash': block['prev_hash'],
                                                #     'block_merkle_root': block['merkle_root']
                                                # }
                                                # return jsonify(response), 200
                                            else:
                                                amountverification=False
                                                # print("not sufficient amount ")
                                                # response = {
                                                #     "message2": "hello wrong"
                                                # }
                            else:
                                continue# return response
            else:
                Blockno_verification=False


                                # print("not valid transaction ")
                                # response = {
                                #     "message2": "hello wrong"
                                # }
                                # return response
                                # checking for other transactions
    print("lengths of c")
    print(len(listoftrans))
    print(virtual_name_verification_c)
    if rec_virtual_name_auth_c==len(listoftrans):
        if virtual_name_verification_c == len(listoftrans):
            if sourceidverification_c==len(listoftrans):
                if pathverification_c==len(listoftrans):
                    if amountverification_c==len(listoftrans):
                        print("transaction successfull")
                        block = blockchain.create_block(virtualname, nonce, prev_hash, hashgenerated, usertx)
                        # try:
                        #     if block["message"]=="same transaction copied":
                        #         print("same transaction copied")
                        #         response = {
                        #             "message2": "hello wrong"
                        #         }
                        #         return response
                        # except KeyError:
                        #     print("new Transaction")
                        #     pass
                        response = {
                            'message': 'new block created',
                            'block_number': block['block_number'],
                            'block_transactions': block['transactions'],
                            'block_nonce': block['nonce'],
                            'block_prev_hash': block['prev_hash'],
                            'block_merkle_root': block['merkle_root']
                        }
                        return jsonify(response), 200
                    else:
                        print("insufficient amount")
                        response = {
                            "message2": "hello wrong"
                        }
                        return response
                else:
                    print("not valid path")
                    response = {
                        "message2": "hello wrong"
                    }
                    return response
            else:
                print("not valid source id")
                response = {
                    "message2": "hello wrong"
                }
                return response
        else:
            print("not valid sender virtual name")
            response = {
                "message2": "hello wrong"
            }
            return response

    else:
        print("not valid recipient virtual name")
        response = {
            "message2": "hello wrong"
        }
        return response



    # # print(type(filedict[0]))
    # # block1file=()
    # # # string_one=str(1)
    # # j=0
    # #
    # # while j < len(filedict):
    # #     if len(filedict)==0:
    # #         print("Null")
    # #         break;
    # #     if filedict[j]['block_number'] == 1:
    # #         # print("hello block whchever")
    # #         # print(filedict[j])
    # #         a=list(block1file)
    # #         a.append(filedict[j])
    # #         a=tuple(a)
    # #         print(a)
    # #         filedict.remove(filedict[j])
    # #         j=0
    # #         filedict.append(a[0])
    # #
    # #     j=j+1
    # # print("after removing block 1")
    # # print(filedict)
    # f=open("publicledger.txt", "a")
    # f.write(json.dumps(filedict, sort_keys=True) + ";")
    f.close()













































@app.route("/chain-of-blocks", methods=['GET'])
def chain():
    response = {
        'chain_of_blocks':blockchain.chain,
        'length_of_blockchain':len(blockchain.chain)
    }

    return  jsonify(response), 200


@app.route("/transactions/admin", methods=['POST'])
def walletadmin():
   # print("callled")
   values = request.form
   adminid="VE#FE"
   global virtualid
   destinationid=[]
   virtualid=[]
   virtualid.append(values['virtualname'])
   destinationid.append(values['sendersourceid'])
   initialamt=50
   # transaction_userpath = values['virtualname']
   # response={
   #   'message':transaction_userpath
   # }
   # return jsonify(response) , 201
   blockno = 1
   admin_trans = []

   #assigning source id to destination id to check for next transaction if destination id is source id or not
   #since admin is sending money to us we will be recipient so virtual id became recipient id
   admin_trans_list=[]
   admin_dict={"virtualname": adminid, "recipientvirtualname": virtualid, "initialamt": initialamt,"destinationid":destinationid}
   admin_trans.append(json.dumps({"virtualname": adminid, "recipientvirtualname": virtualid, "initialamt": initialamt,"destinationid":destinationid}, sort_keys=True))
   admin_mt = MerkleTree(admin_trans)
   adminhash=admin_mt.compute_hash(admin_trans[0])
   adminpath=admin_mt.get_txpath(adminhash)
   if len(adminpath)>1:
       adminpath=adminpath[-1:]
   print("admin path")
   print(adminpath)
   # user_tx={"adminhash":adminhash, "adminpath":adminpath}
   # print(user_tx)
   admin_dict["adminhash"]=adminhash
   admin_dict["adminpath"]=adminpath
   admin_trans_list.append(admin_dict)
   blockchain=Blockchain()
   blockchain.transactions=admin_trans_list
   blockchain.create_block(adminid, "0","0", admin_mt.root.hash,virtualid) #here usertx is "recipientvirtualname": virtualid
   return jsonify(admin_mt.root.hash) ,201

@app.route("/transactions/new", methods=['POST'])
def newtransaction():
    values = request.form
    print(values)
    n=values['noofdestinations']
    virtualid=values['sendervirtualname']
    print(virtualid)
    finaldestinationsid=[]
    finalrecipientvirtualname = []
    finalamount=[]
    finalpath=[]
    finalrecipientpublickeys=[]
    finalblocks=[]
    finalhashtrans=[]
    i=1
    while i<int(n)+1:
        stringi=str(i)
        finalrecipientpublickeys.append(values["recipient_public_key"+stringi])
        finaldestinationsid.append(values["final_destination"+stringi])
        finalamount.append(values["final_amount"+stringi])
        finalpath.append(values["path_amount"+stringi])
        finalblocks.append(values["finalblocknumber"+stringi])
        finalhashtrans.append(values["finalprevhashtrans"+stringi])
        finalrecipientvirtualname.append(values["recipient_virtualname" + stringi])
        i=i+1


    # n = values['noofdestinations']
    # print(n)
    # check missing values
    # required = ['confirmation_sender_public_key','senderid','confirmation_recipient_public_key', 'transaction_signature']
    # if not all(k in values for k in required):
    #     return "Missing values found",400
    #transaction result is the block number to which transaction is added
    transaction_result = blockchain.submit_transaction(values['sendervirtualname'],values['senderid'],values['confirmation_sender_public_key'],
                                                        values['transaction_signature'], finaldestinationsid,finalamount,finalpath,finalrecipientpublickeys,finalblocks,finalhashtrans,finalrecipientvirtualname)

    if transaction_result == False:
        response = {'message': 'invalid'}
        return jsonify(response), 406
    else:
        response = {'message': 'Transaction will be added to block ' + str(transaction_result)}
        return jsonify(response), 201

@app.route('/nodes/get', methods=['GET'])
def getnodes():
    # getting the list of all the nodes
    nodes = list(blockchain.nodes)
    response = {'nodes': nodes}
    return jsonify(response), 200


@app.route('/nodes/register', methods=['POST'])
def register_node():
    values = request.form
    # 127.0.0.1:5002,127.0.0.1:5003, 127.0.0.1:5004
    nodes = values.get('nodes').replace(' ', '').split(',')  # getting the array of nodes which are present as a string

    if nodes is None:
        return 'Error: Please supply a valid list of nodes', 400

    for node in nodes:
        blockchain.register_node(node)

    response = {
        'message': 'Nodes have been added',
        'total_nodes': [node for node in blockchain.nodes]
    }

    return jsonify(response), 200


@app.route('/nodes/resolve', methods=['GET'])
def consensus():
    replaced = blockchain.resolve_conflicts()

    if replaced:
        response = {
            'message': 'Our chain was replaced',
            'new_chain': blockchain.chain
        }
    else:
        response = {
            'message': 'Our chain is authoritative',
            'chain': blockchain.chain
        }
    return jsonify(response), 200


#this process comes in mining as we check if user has sufficient amt or not
@app.route("/transactions/verify", methods=['POST'])
def verfiy_usertransaction():
   transactionpath=[]
   print("callled")
   values = request.form
   transactionpath.append(values['confirm_transactionpath'])
   print(type(transactionpath))
   transactionhash=values['confirm_transactionhash']
   response={
       "transactionpath":transactionpath,
       "transactionhash":transactionhash
   }
   checkpath=verify_txpath(transactionhash,transactionpath)
   print(checkpath)
   MerkleTree.amtintransaction(checkpath)
   # if checkpath:
   #     return "trnasction exist"
   # else:
   #     return "doesnot"


if __name__ == '__main__':  # checking the name
    from argparse import ArgumentParser

    parser = ArgumentParser()  # argument parser function
    parser.add_argument('-p', '--port', default=5001, type=int,
                        help="port to listen to")  # add port argument to the object
    args = parser.parse_args()  # parse the argument for getting separate value
    port = args.port  # get the port value from parsed argument

    app.run(host='127.0.0.1', port=port, debug=True)

