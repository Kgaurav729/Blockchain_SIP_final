from flask import Flask, request, jsonify, render_template
import Crypto
import Crypto.Random
from Crypto.PublicKey import RSA
import binascii
from collections import OrderedDict
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA
import random
import json
import os


transaction_details=[]
import pyautogui

class Transactions:
    def __init__(self, sender_publickey, sender_privatekey,virtualid,sourceid,newsourceid,recipient_publickey=[],amountid=[], destinationid=[],path=[],blocknumbers=[],prevhashtrans=[],recipient_virtual_name=[]):
        self.sender_publickey = sender_publickey
        self.sender_privatekey = sender_privatekey
        self.recipient_publickey = recipient_publickey
        self.amountid = amountid
        self.sourceid = sourceid
        self.virtualid=virtualid
        self.destinationid = destinationid
        self.newsourceid = newsourceid
        self.path=path
        self.blocknumbers=blocknumbers
        self.prevhashtrans=prevhashtrans
        self.recipient_virtual_name=recipient_virtual_name

    def to_dict(self): # to convert transaction into dictionary
        return OrderedDict({
            'sourceid': self.sourceid,
            'destination_transactions': self.destinationid,
            'amount_transactions': self.amountid,
            'sender_publickey': self.sender_publickey,
            'recipient_publickey':self.recipient_publickey,
            'path_transactions':self.path,
            'virtualid':self.virtualid,
            'blocknumber':self.blocknumbers,
            'previoushashtransaction':self.prevhashtrans,
            'recipient_virtual_name':self.recipient_virtual_name
        })

    def to_sign(self):
        private_key = RSA.importKey(binascii.unhexlify(self.sender_privatekey)) # get private key of sender and unhexify it
        signer = PKCS1_v1_5.new(private_key)
        # we will sign the content of transaction
        hashgenerated = SHA.new(str(self.to_dict()).encode('utf8')) # get transaction details and convert to string and hash it
        return binascii.hexlify(signer.sign(hashgenerated)).decode('ascii') # using the private key we will sign the hash generated of the transaction
                # signature = private key of sender + hash of the transaction





app = Flask(__name__)
@app.route("/")
def index():
    return render_template("./index.html")  # this function will redirect to index.html file in templates folder


@app.route("/make-transaction")
def make_transaction():
    return render_template("./make-transaction.html")


@app.route("/generate-transaction", methods=['post'])
def generate_transaction():
    i = 0
    prevhashtransaction=[]
    blocknumbers=[]
    recipient_public_key=[]
    recipient_virtual_name=[]
    amount_transfer = []
    destination_transfer = []
    path_transfer=[]
    virtualid=request.form['virtualname']
    print(virtualid)
    sourceid = request.form['sourceid']
    sender_publickey = request.form['sender_publickey']
    sender_privatekey = request.form['sender_privatekey']
    no_of_path = request.form['opt']
    no_finalpath = int(no_of_path)
    print(no_finalpath)
    while i < no_finalpath:
        amount_transfer.append(request.form['Amount'+str(i+1)])
        recipient_virtual_name.append(request.form['recipientvirtualname' + str(i + 1)])
        print(recipient_virtual_name[i])
        destination_transfer.append(request.form['destination'+str(i+1)])
        path_transfer.append(request.form['path'+str(i+1)])
        recipient_public_key.append(request.form['recipient_publickey'+str(i+1)])
        blocknumbers.append(request.form['blocknumber'+str(i+1)])
        prevhashtransaction.append(request.form['hashprevtrans'+str(i+1)])
        i=i+1

    newsourceid= random.randint(0,100000)


    # making object of class Transactions
    transaction = Transactions(sender_publickey, sender_privatekey,virtualid,sourceid, newsourceid,recipient_public_key, amount_transfer ,destination_transfer,path_transfer,blocknumbers,prevhashtransaction,recipient_virtual_name)
    transaction_dict = transaction.to_dict()
    print(transaction_dict)

    # totalsum = 0
    # if len(transaction_details) == 0:
    #     transaction_details.append(transaction_dict)
    # else:
    #     flag=0
    #     for j in range(len(transaction_details)):
    #         if transaction_dict['sourceid'] == transaction_details[j]['destinationid']:
    #             flag=1
    #             totalsum = totalsum+int(transaction_details[j]['amount'])
    #             print(transaction_details[j]['amount'] )
    #             print(totalsum)
    #
    #     if int(transaction_dict['amount']) > totalsum and flag == 1:
    #         print("amount not sufficient")
    #     else:
    #         transaction_details.append(transaction_dict)
    #
    #
    #
    # print(transaction_details)


    response = {
        'noofpaths' : no_finalpath,
        'transaction': transaction_dict,# convert transactions to dictionary using function
        'signature': transaction.to_sign()
    }
    # print(response)
    return jsonify(response), 200
    # always return the response in json format


@app.route("/verify-transactions")  # if request contains / then this function will run (Default)
def verify():
    return render_template("./verify_transaction.html")

@app.route("/view-transactions")
def view_transactions():
    return render_template("./view-transactions.html")

@app.route("/new-wallet",methods=['post'])
def newwallet():
    username = request.form['virtualusername']
    print(username)
    random_sourceid = random.randint(0,100000)
    # filename1 = "sourceids.txt"
    # file_exists = os.path.exists(filename1)
    # if file_exists:
    #     sd = open(filename1)
    #     sd = open(filename1, "r")
    #     data = sd.read()
    #     data = (data.split(" "))[:-1]
    #     for s in data:
    #         if random_sourceid == s:
    #             s = {
    #                 "message": "Username Already taken!"
    #             }
    #             print("already used source id")
    #             return jsonify(s)
    #         else:
    #             sd = open(filename1, "a")
    #             sd.write(str(random_sourceid) + " ")
    # else:
    #     sd = open(filename1, "x")
    #     sd = open(filename1, "a")
    #     sd.write(str(random_sourceid) + " ")
    # sd.close()

    random_generator = Crypto.Random.new().read
    privatekey = RSA.generate(1024, random_generator) # rsa 1024 bits with random value
    publickey = privatekey.public_key()

    s = {
        'virtualusername':username,
        'sourceid': random_sourceid,
        'privatekey': binascii.hexlify(privatekey.exportKey(format('DER'))).decode('ascii'),
        'publickey': binascii.hexlify(publickey.exportKey(format('DER'))).decode('ascii')
    }


    # virtual_id = {"Source id": random_sourceid, "public key": binascii.hexlify(publickey.exportKey(format('DER'))).decode('ascii'), "private key": binascii.hexlify(privatekey.exportKey(format('DER'))).decode('ascii')}
    file_exists = os.path.exists("{virtualid}.txt".format(virtualid=username))
    if file_exists:
        s = {
            "message": "Username Already taken!"
        }
        return jsonify(s), 200

    else:
        # intialamount=50
        # adminid="Ve#@1"
        # filename="{virtualid}.txt".format(virtualid=username)
        #
        # f = open(filename, "x")
        # f = open(filename)
        # f = open(filename, "a")
        #
        # # virtual_id2 = json.dumps(virtual_id,sort_keys=True)  # convert object to json string and use sort keys to make them in ordered form
        # #
        # # f.write(virtual_id2 + "\n")
        # money={"Admin":adminid,"Sourceid":random_sourceid,"Amount initial":intialamount}
        # transactionintial = json.dumps(money, sort_keys=True)
        # f.write(transactionintial)
        # f.close()
        # file1 = open("publicdetails.txt", "a")
        # public_details = {"Virtual Name":username,"public key": binascii.hexlify(publickey.exportKey(format('DER'))).decode('ascii')}
        # public_write = json.dumps(public_details,sort_keys=True)  # convert object to json string and use sort keys to make them in ordered form
        #
        # file1.write(public_write + "\n")
        # file1.close()

        # printing the list of files in txt format

        # for file in os.listdir("blockchainnew/blockchain_client"):
        #     if file.endswith(".txt"):
        #         print(os.path.join("blockchainnew/blockchain_client", file))

        return jsonify(s)

@app.route("/verifyusertransactions",methods=['post'])  #
def verifyusertransaction():
    values = request.form
    transactionpath = values['transaction_path']
    transactionhash=values['transaction_hash']
    transactionblock=values['transaction_blocknumber']
    print(values)
    response = {
        'transactionpath': transactionpath,
        'transactionhash': transactionhash,  # convert transactions to dictionary using function
        'transactionblock': transactionblock
    }

    return jsonify(response), 201








if __name__ == '__main__':  # checking the name
    from argparse import ArgumentParser

    parser = ArgumentParser()  # argument parser function
    parser.add_argument('-p', '--port', default=8081, type=int, help="port to listen to")  # add port argument to the object
    args = parser.parse_args()  # parse the argument for getting separate value
    port = args.port  # get the port value from parsed argument

    app.run(host='127.0.0.1', port=port, debug=True)
